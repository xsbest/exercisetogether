<template>
    <div>123213123123</div>
</template>

<script>
export default {
  name: 'Content',
}
</script>

<style>

</style>